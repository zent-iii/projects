﻿namespace Beadando
{
    public class Ceg
    {
        private List<Jarmu> jarmuvek;
        private string ceg_nev;
        public Ceg(string nev)
        {
            jarmuvek = new List<Jarmu>();
            this.ceg_nev = nev;
        }
        public void JarmuAdd(Jarmu jarmu)
        {
            foreach (Munkalap item in jarmu.munkalapok)
            {
                if (item.szerviz_id == ceg_nev && !jarmuvek.Contains(jarmu))
                {
                    jarmuvek.Add(jarmu);
                }
            }
        }
        public void Vizsgalat_megkezdese(Jarmu j, string m_id, string j_id, string vizsgalat_kezdete, Vizs_faj vizs_fajta)
        {
            if (jarmuvek.Contains(j))
            {
                throw new InvalidOperationException("Már szervizelik ezt a járművet.");
            }
            j.Szervizbe();
            Munkalap munkalap = new Munkalap(m_id, this.ceg_nev, j_id, vizsgalat_kezdete, vizs_fajta, null);
            j.munkalapok.Add(munkalap);
            jarmuvek.Add(j);
        }
        public void TetelekFelkerulese(Jarmu j, Munkalap m, Tetel t)
        {
            foreach (Jarmu e in jarmuvek)
            {
                if (e == j)
                {
                    foreach (Munkalap f in e.munkalapok)
                    {
                        if (f == m)
                        {
                            f.TetelekAdd(t);
                            f.Folyamatban();
                        }
                    }
                }
            }
        }
        public void Vizsgalat_befejezese(Jarmu j,Munkalap m, string vizsgalat_befejezese)
        {
            m.Lezar(vizsgalat_befejezese);
            j.Szolgalatba();
            jarmuvek.Remove(j);
        }
    }
}
