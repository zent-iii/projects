﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Beadando
{
    public enum Vizs_faj
    {
        atvizsgalas,
        javitas
    }
    public enum MunkalapAllapot {
        uj,
        folyamatban,
        lezart
    }
    public record Tetel(string munkalap_id, string munkafolyamat, int koltseg);
    public class Munkalap
    {
        public string munkalap_id { get; private set; }
        public string szerviz_id { get; private set; }
        public string jarmu_id { get; private set; }
        public string vizsgalat_k { get; set; }
        public string? vizsgalat_v { get; set; }
        public Vizs_faj vizsgalat_f { get; private set;}
        public MunkalapAllapot allapot { get; set; }
        public List<Tetel> tetelek { get; private set; }
        public int TeljesKoltseg { get; private set; }
        public Munkalap(string munkalap, string szerviz, string jarmu, string v_k, Vizs_faj v_f, string v_v)
        {
            this.munkalap_id = munkalap;

            this.szerviz_id = szerviz;
            this.jarmu_id = jarmu;
            vizsgalat_k = v_k;
            vizsgalat_v = v_v;
            vizsgalat_f = v_f;
            tetelek = new List<Tetel>();
            TeljesKoltseg = 0;
            if (string.IsNullOrEmpty(v_v))
            {
                this.allapot = MunkalapAllapot.lezart;
            }
            else
            {
                this.allapot = MunkalapAllapot.uj;
            }
        }
        public void TetelekAdd(Tetel tetel)
        {
            if (tetel.munkalap_id == this.munkalap_id)
            {
                tetelek.Add(tetel);
            }
            if (allapot == MunkalapAllapot.uj)
            {
                Folyamatban();
            }
        }
        public void Folyamatban()
        {
            if (tetelek.Count > 0)
            {
                allapot = MunkalapAllapot.folyamatban;
            }
        }
        public void Lezar(string vegDatum)
        {
            this.vizsgalat_v = vegDatum;
            allapot = MunkalapAllapot.lezart;
            int szervizeles_ara = 0;
            foreach (Tetel tetel in tetelek)
            {
                szervizeles_ara += tetel.koltseg;
            }
            this.TeljesKoltseg = szervizeles_ara;
        }

    }
}
