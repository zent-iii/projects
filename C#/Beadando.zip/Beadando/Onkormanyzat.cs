﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Beadando
{
    public class Onkormanyzat
    {
        private List<Ceg> szerzodott_cegek;
        public List<Jarmu> jarmuvek { get; set; }
        public Onkormanyzat()
        {
            szerzodott_cegek = new List<Ceg>();
            jarmuvek = new List<Jarmu>();
        }
        public void Szerzodes_alairasa(Ceg c)
        {
            if (c != null && !szerzodott_cegek.Contains(c))
            {
                szerzodott_cegek.Add(c);
            }
        }
        public void Szerzodes_felbontasa(Ceg c)
        {
            szerzodott_cegek.Remove(c);
        }
        public void SzervizbeKuldes(Jarmu j)
        {
            foreach (Jarmu e in jarmuvek)
            {
                if (e == j)
                {
                    e.Szervizbe();
                    break;
                }
            }
        }
        public void SzolgalatbaVissza (Jarmu j)
        {
            foreach (Jarmu e in jarmuvek)
            {
                if (e == j)
                {
                    e.Szolgalatba();
                    break;
                }
            }
        }
        public double Eloregedett_buszok()
        {
            double db = 0;
            double osszes_db = 0;
            int aktualis_ev = DateTime.Now.Year;
            foreach (Jarmu e in jarmuvek)
            {
                if (e is Autobusz)
                {
                    osszes_db++;
                }
                if (aktualis_ev - int.Parse(e.gyer) > 15 && e is Autobusz)
                {
                    db++;
                }
            }
            return db / osszes_db;
        }
        public Jarmu Max_koltseg()
        {
            Jarmu j = jarmuvek[0];
            double max_koltseg = jarmuvek[0].ujar - jarmuvek[0].Aktualis_ertek();
            foreach (Munkalap m in j.munkalapok)
            {
                int szervizeles_ara = 0;
                foreach (Tetel tetel in m.tetelek)
                {
                    szervizeles_ara += tetel.koltseg;
                }
                max_koltseg += szervizeles_ara;
            }
            for (int i = 1; i < jarmuvek.Count; i++)
            {
                double koltseg = jarmuvek[i].ujar - jarmuvek[i].Aktualis_ertek();
                foreach (Munkalap m in jarmuvek[i].munkalapok)
                {
                    foreach (Tetel tetel in m.tetelek)
                    {
                        koltseg += tetel.koltseg;
                    }
                }
                if (max_koltseg < koltseg)
                {
                    max_koltseg = koltseg;
                    j = jarmuvek[i];
                }
            }
            return j;
        }
        public double Javitasalatt()
        {
            double db = 0;
            foreach (Jarmu j in jarmuvek)
            {
                if (j.allapot == JarmuAllapot.szervizben)
                {
                    foreach (Munkalap m in j.munkalapok)
                    {
                        if (m.allapot != MunkalapAllapot.lezart && m.vizsgalat_f == Vizs_faj.javitas)
                        {
                            db++;
                        }
                    }
                }
            }
            return db / jarmuvek.Count;
        }
    }
}
