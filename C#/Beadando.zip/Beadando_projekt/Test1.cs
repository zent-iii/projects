﻿namespace Beadando
{
    [TestClass]
    public class CegTests
    {
        private Ceg ceg;
        private Villamos villamos;
        private Kulvaros ovezet;

        [TestInitialize]
        public void TestInitialize()
        {
            ceg = new Ceg("BKV");
            ovezet = new Kulvaros();
            villamos = new Villamos("V001", "2015", ovezet, 100_000);
        }

        [TestMethod]
        public void VizsgalatMegkezdese_HelyesenHozzaadjaAJarmuvetEsMunkalapot()
        {
            string munkalapId = "M123";
            string jarmuId = "V001";
            string kezdesDatum = "2024.05.01";
            Vizs_faj fajta = Vizs_faj.javitas;
            ceg.Vizsgalat_megkezdese(villamos, munkalapId, jarmuId, kezdesDatum, fajta);
            Assert.AreEqual(JarmuAllapot.szervizben, villamos.allapot);
            Assert.AreEqual(1, villamos.munkalapok.Count);
            Assert.AreEqual(munkalapId, villamos.munkalapok[0].munkalap_id);
            Assert.AreEqual("BKV", villamos.munkalapok[0].szerviz_id);
            Assert.AreEqual(jarmuId, villamos.munkalapok[0].jarmu_id);
            Assert.AreEqual(kezdesDatum, villamos.munkalapok[0].vizsgalat_k);
            Assert.AreEqual(fajta, villamos.munkalapok[0].vizsgalat_f);
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidOperationException))]
        public void VizsgalatMegkezdese_KetszerDobHibat()
        {
            ceg.Vizsgalat_megkezdese(villamos, "M1", "V001", "2024.05.01", Vizs_faj.atvizsgalas);
            ceg.Vizsgalat_megkezdese(villamos, "M2", "V001", "2024.05.02", Vizs_faj.javitas);
        }
        [TestMethod]
        public void VizsgalatBefejezese_HelyesenLezarjaAMunkalapot()
        {
            string munkalapId = "M456";
            string befejezesDatum = "2024.05.10";
            ceg.Vizsgalat_megkezdese(villamos, munkalapId, "V001", "2024.05.01", Vizs_faj.javitas);
            Munkalap munkalap = villamos.munkalapok[0];
            Tetel tetel1 = new Tetel(munkalapId, "Kerékcsere", 10000);
            Tetel tetel2 = new Tetel(munkalapId, "Fékcsere", 15000);
            ceg.TetelekFelkerulese(villamos, munkalap, tetel1);
            ceg.TetelekFelkerulese(villamos, munkalap, tetel2);
            ceg.Vizsgalat_befejezese(villamos, munkalap, befejezesDatum);
            Assert.AreEqual(MunkalapAllapot.lezart, munkalap.allapot);
            Assert.AreEqual(befejezesDatum, munkalap.vizsgalat_v);
            Assert.AreEqual(25000, munkalap.TeljesKoltseg);
            Assert.AreEqual(JarmuAllapot.szolgalatban, villamos.allapot);
        }
        [TestMethod]
        public void AktualisErtekTest()
        {
            Belvaros b = new Belvaros();
            var jarmu = new Autobusz("BUS1", "2010", b, 100000);
            int jelenlegi_ev = DateTime.Now.Year;
            int kor = jelenlegi_ev - 2010;
            double vart = 100000 * (100 - kor) / (100 * 2.0);
            vart = Math.Round(vart);
            double valos = jarmu.Aktualis_ertek();
            Assert.AreEqual(vart, valos);
        }
        [TestMethod]
        public void EloregedettBuszokTest()
        {
            Onkormanyzat onkormanyzat = new Onkormanyzat();
            int currentYear = DateTime.Now.Year;
            Belvaros b = new Belvaros();
            Kulvaros k = new Kulvaros();
            Vegyes v = new Vegyes();
            onkormanyzat.jarmuvek.AddRange(new[]
            {
                new Autobusz("BUS1", (currentYear - 20).ToString(), b, 100000),
                new Autobusz("BUS2", (currentYear - 10).ToString(), k, 100000),
                new Autobusz("BUS3", (currentYear - 5).ToString(), v, 100000)
            });
            double expected = 1.0 / 3;
            double actual = onkormanyzat.Eloregedett_buszok();
            Assert.AreEqual(expected, actual, 0.001);
        }
        [TestMethod]
        public void JavitasAlattTest()
        {
            var onkormanyzat = new Onkormanyzat();
            Belvaros b = new Belvaros();
            Jarmu jarmu = new Autobusz("BUS1", "2010", b, 100000);
            var munkalap = new Munkalap("M1", "Ceg1", "BUS1", "2023-01-01", Vizs_faj.javitas, null);
            munkalap.allapot = MunkalapAllapot.folyamatban;
            jarmu.munkalapok.Add(munkalap);
            jarmu.Szervizbe();
            onkormanyzat.jarmuvek.Add(jarmu);
            double expected = 1.0 / 1;
            double actual = onkormanyzat.Javitasalatt();
            Assert.AreEqual(expected, actual);
        }
    }
}
