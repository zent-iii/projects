﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HF7
{
    internal class Card
    {
        public string cNum;
        public string pincode { get; private set; }
        public Card(string c, string p)
        {
            this.cNum = c;
            this.pincode = p;
        }
        public bool CheckPIN(string p)
        {
            return pincode == p;
        }
        public void SetPIN(string p) { pincode = p; }
    }
}
