﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HF7
{
    internal class Account
    {
        public string accNum { get; private set; }
        private int balance;
        public List<Card> cards;
        public Account(string a)
        {
            this.accNum = a;
            this.balance = 0;
            cards = new List<Card>();
        }
        public int GetBalance()
        {
            return balance;
        }
        public void Change(int a)
        {
            balance += a;
        }
        public void AddCard(Card c)
        {
            cards.Add(c);
        }
    }
}
