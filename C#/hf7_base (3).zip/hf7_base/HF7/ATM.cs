﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HF7
{
    internal class ATM
    {
        private Center center;
        private string location;
        public ATM(string t, Center c)
        {
            this.location = t;
            this.center = c;
        }
        public void Process(Customer customer)
        {
            Card card = customer.ProvidesCard();
            if (card.CheckPIN(customer.ProvidesPIN()))
            {
                int amount = customer.RequestMoney();
                if (center.GetBalance(card.cNum) >= amount)
                {
                    center.Transaction(card.cNum, -amount);
                }
            }
        }
    }
}
