﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HF7
{
    internal class Bank
    {
        private Dictionary<string, Account> accounts;
        public Bank()
        {
            accounts = new Dictionary<string, Account>();
        }
        public void OpenAccount(string accNum, Customer customer)
        {
            Account acc = new Account(accNum);
            accounts[accNum] = acc;
            customer.AddAccount(acc);
        }
        public void ProvidesCard(string accNum)
        {
            if (accounts.ContainsKey(accNum))
            {
                var card = new Card(accNum, "");
                accounts[accNum].AddCard(card);
            }
        }
        public int GetBalance(string accNum)
        {
            if (accounts.ContainsKey(accNum))
            {
                return accounts[accNum].GetBalance();
            }
            return -1;
        }
        public void Transaction(string accNum, int amount)
        {
            if (accounts.ContainsKey(accNum))
            {
                accounts[accNum].Change(amount);
            }
        }
        public bool CheckAccount(string accNum)
        {
            return accounts.ContainsKey(accNum);
        }
    }
}
