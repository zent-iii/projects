﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;

namespace HF7
{
    internal class Customer
    {
        private List<Account> accounts;
        private string PIN;
        private int moneyWithdraw; 
        public Customer(string PIN, int w)
        {
            accounts = new List<Account>();
            this.PIN = PIN;
            this.moneyWithdraw = w;
        }
        public void Withdrawal(ATM atm)
        {
            atm.Process(this);
        }
        public void AddAccount(Account account)
        {
            accounts.Add(account);
        }
        public Card ProvidesCard()
        {
            foreach (var item in accounts)
            {
                if (item.cards.Count > 0)
                {
                    return item.cards[0];
                }
            }
            return null;
        }
        public string ProvidesPIN()
        {
            return PIN;
        }
        public int RequestMoney()
        {
            return moneyWithdraw;
        }
    }
}
