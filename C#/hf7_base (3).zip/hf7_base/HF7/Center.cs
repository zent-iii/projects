﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HF7
{
    internal class Center
    {
        private List<Bank> banks;
        public Center(List<Bank> b)
        {
            banks = b;
        }
        public int GetBalance(string accNum)
        {
            foreach (Bank bank in banks)
            {
                if (bank.CheckAccount(accNum))
                {
                    return bank.GetBalance(accNum);
                }
            }
            return -1;
        }
        public void Transaction(string accNum, int amount)
        {
            foreach (Bank bank in banks)
            {
                if (bank.CheckAccount(accNum))
                {
                    bank.Transaction(accNum, amount);
                    return;
                }
            }
        }
    }
}
