﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Beadando
{
    public enum JarmuAllapot
    {
        szolgalatban,
        szervizben
    }
    public abstract class Jarmu
    {
        public string azonosito { get; protected set; }
        public string gyer { get; protected set; }
        protected Hasznalati_ovezet hasznalati_ovezet;
        public JarmuAllapot allapot { get; set; }
        public int ujar { get; protected set; }
        public List<Munkalap> munkalapok { get; protected set; }
        protected Jarmu(string azo, string gy, Hasznalati_ovezet h, int ujar)
        {
            azonosito = azo;
            gyer = gy;
            hasznalati_ovezet = h;
            munkalapok = new List<Munkalap>();
            this.ujar = ujar;
            allapot = JarmuAllapot.szolgalatban;
        }
        public void MunkalapAdd(Munkalap m)
        {
            if (this.azonosito == m.jarmu_id && !munkalapok.Contains(m))
            {
                if (m.allapot != MunkalapAllapot.lezart)
                {
                    this.Szervizbe();
                }
                munkalapok.Add(m);
            }
        }
        public void Szervizbe()
        {
            this.allapot = JarmuAllapot.szervizben;
        }
        public void Szolgalatba()
        {
            this.allapot = JarmuAllapot.szolgalatban;
        }
        public abstract double Aktualis_ertek();
        public int OsszesSzervizKoltseg()
        {
            int osszKoltseg = 0;
            foreach (Munkalap m in munkalapok)
            {
                if (m.allapot == MunkalapAllapot.lezart)
                {
                    osszKoltseg += m.TeljesKoltseg;
                }
            }
            return osszKoltseg;
        }
        public abstract double TeljesKoltseg();
    }
    public sealed class Villamos : Jarmu
    {
        public Villamos(string azo, string gy, Hasznalati_ovezet h, int ujar) : base(azo, gy, h, ujar) { }
        public double Faktor()
        {
            return hasznalati_ovezet.Szorzo(this);
        }
        public override double Aktualis_ertek()
        {
            double faktor = this.Faktor();
            int current_year = DateTime.Now.Year;
            double ertek = this.ujar * (100 - (current_year - int.Parse(this.gyer))) / (100 * faktor);
            return ertek;
        }
        public override double TeljesKoltseg()
        {
            double ertekcsokkenes = this.ujar - this.Aktualis_ertek();
            int szervizKoltseg = this.OsszesSzervizKoltseg();
            return ertekcsokkenes + szervizKoltseg;
        }
    }
    public sealed class Autobusz : Jarmu
    {
        public Autobusz(string azo, string gy, Hasznalati_ovezet h, int ujar) : base(azo, gy, h, ujar) { }
        public double Faktor()
        {
            return hasznalati_ovezet.Szorzo(this);
        }
        public override double Aktualis_ertek()
        {
            double faktor = this.Faktor();
            int current_year = DateTime.Now.Year;
            double ertek = this.ujar * (100 - (current_year - int.Parse(this.gyer))) / (100 * faktor);
            return ertek;
        }
        public override double TeljesKoltseg()
        {
            double ertekcsokkenes = this.ujar - this.Aktualis_ertek();
            int szervizKoltseg = this.OsszesSzervizKoltseg();
            return ertekcsokkenes + szervizKoltseg;
        }
    }
    public sealed class Trolibusz : Jarmu
    {
        public Trolibusz(string azo, string gy, Hasznalati_ovezet h, int ujar) : base(azo, gy, h, ujar) { }
        public double Faktor()
        {
            return hasznalati_ovezet.Szorzo(this);
        }
        public override double Aktualis_ertek()
        {
            double faktor = this.Faktor();
            int current_year = DateTime.Now.Year;
            double ertek = this.ujar * (100 - (current_year - int.Parse(this.gyer))) / (100 * faktor);
            return ertek;
        }
        public override double TeljesKoltseg()
        {
            double ertekcsokkenes = this.ujar - this.Aktualis_ertek();
            int szervizKoltseg = this.OsszesSzervizKoltseg();
            return ertekcsokkenes + szervizKoltseg;
        }
    }
}
