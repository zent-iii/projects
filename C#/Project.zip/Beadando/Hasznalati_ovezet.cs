﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Beadando
{
    public interface Hasznalati_ovezet {
        public double Szorzo(Villamos villamos);
        public double Szorzo(Autobusz autobusz);
        public double Szorzo(Trolibusz trolibusz);
    } 
    public sealed class Belvaros : Hasznalati_ovezet
    {
        private static readonly Belvaros _instance = new Belvaros();
        public static Belvaros Instance => _instance;
        private Belvaros() { }
        public double Szorzo(Villamos villamos)
        {
            return 1.0;
        }
        public double Szorzo(Autobusz autobusz)
        {
            return 2.0;
        }
        public double Szorzo(Trolibusz trolibusz)
        {
            return 3.0;
        }
    }
    public sealed class Kulvaros : Hasznalati_ovezet
    {
        private static readonly Kulvaros _instance = new Kulvaros();
        public static Kulvaros Instance => _instance;
        private Kulvaros() { }
        public double Szorzo(Villamos villamos)
        {
            return 0.9;
        }
        public double Szorzo(Autobusz autbusz)
        {
            return 2.0;
        }
        public double Szorzo(Trolibusz trolibusz)
        {
            return 3.1;
        }
    }
    public sealed class Vegyes : Hasznalati_ovezet
    {
        private static readonly Vegyes _instance = new Vegyes();
        public static Vegyes Instance => _instance;
        private Vegyes() { }
        public double Szorzo(Villamos villamos)
        {
            return 1.2;
        }
        public double Szorzo(Autobusz autobusz)
        {
            return 2.5;
        }
        public double Szorzo(Trolibusz trolibusz)
        {
            return 3.8;
        }
    }
}
