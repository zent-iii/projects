﻿using System.Runtime.CompilerServices;
using System.Xml;

namespace Beadando
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Jarmu> jarmuvek = JarmuFajlBeolvas("jarmu_input.txt");
            List<Ceg> szervizek = Szerviz_Beolvas("szerviz_input.txt");
            List<Munkalap> munkalapok = Munkalapok_Beolvas("munkalapok_input.txt");
            List<Tetel> tetelek = MunkaFolyamatok_Beolvas("munkafolyamatok_input.txt");
            foreach (Munkalap munkalap in munkalapok)
            {
                foreach (Tetel tetel in tetelek) { munkalap.TetelekAdd(tetel); }
            }
            foreach (Jarmu j in jarmuvek)
                {
                    foreach (Munkalap m in  munkalapok) {
                    j.MunkalapAdd(m); 
                }
                }
            foreach (Ceg c in szervizek)
                {
                    foreach (Jarmu j in jarmuvek) { c.JarmuAdd(j); }
                }
            Onkormanyzat onkormanyzat = new Onkormanyzat();
            foreach (Ceg c in szervizek)
            {
                onkormanyzat.Szerzodes_alairasa(c);
            }
            foreach (Jarmu j in jarmuvek)
            {
                onkormanyzat.jarmuvek.Add(j);
            }
            double max_eloregedett = onkormanyzat.Eloregedett_buszok();
            Jarmu legdragabb_jarmu = onkormanyzat.Max_koltseg();
            double javitas_alatt = onkormanyzat.Javitasalatt();
            Console.WriteLine(max_eloregedett);
            Console.WriteLine(legdragabb_jarmu.azonosito);
            Console.WriteLine(javitas_alatt);
        }
        public static List<Jarmu> JarmuFajlBeolvas(string fajlnev)
        {
            List<Jarmu> jarmuvek = new List<Jarmu>();
            StreamReader sr = new StreamReader(fajlnev);
            string? sor;
            while ((sor = sr.ReadLine()) != null)
            {
                string[] adatok = sor.Split(';');
                Jarmu? jarmu = CreateJarmu(adatok[0], adatok[1], adatok[2], adatok[3], Int32.Parse(adatok[4]));
                jarmuvek.Add(jarmu);
            }
            return jarmuvek;
        }
        public static List<Ceg> Szerviz_Beolvas(string fajlnev)
        {
            List<Ceg> cegek = new List<Ceg>(); 
            StreamReader sr = new StreamReader(fajlnev);
            string? sor;
            while ((sor = sr.ReadLine()) != null)
            {
                Ceg c = new Ceg(sor);
                cegek.Add(c);
            }
            return cegek;
        }
        public static List<Munkalap> Munkalapok_Beolvas(string fajlnev)
        {
            List<Munkalap> munkalapok = new List<Munkalap>();
            StreamReader sr = new StreamReader(fajlnev);
            string? sor;
            while ((sor = sr.ReadLine()) != null)
            {
                string[] adatok = sor.Split(';');
                Munkalap m = new Munkalap(adatok[0], adatok[1], adatok[2], adatok[3], (Vizs_faj)Enum.Parse(typeof(Vizs_faj), adatok[4]), adatok[5]);
                munkalapok.Add(m);
            }
            return munkalapok;
        }
        public static List<Tetel> MunkaFolyamatok_Beolvas(string fajlnev)
        {
            List<Tetel> tetelek = new List<Tetel>();
            StreamReader sr = new StreamReader(fajlnev);
            string? sor;
            while ((sor = sr.ReadLine()) != null)
            {
                string[] adatok = sor.Split(';');
                Tetel t = new Tetel(adatok[0], adatok[1], int.Parse(adatok[2]));
                tetelek.Add(t);
            }
            return tetelek;
        }
        public static Jarmu CreateJarmu(string azo, string tipus, string gyer, string hasznalati_ovezet, int ujar)
        {
            Hasznalati_ovezet ovezet = CreateOvezet(hasznalati_ovezet);
            if (string.IsNullOrEmpty(tipus))
            {
                throw new ArgumentException("A jármű típusa nem lehet üres.");
            }
            if (tipus == "villamos")
            {
                return new Villamos(azo, gyer, ovezet, ujar);
            }
            else if (tipus == "autobusz")
            {
                return new Autobusz(azo, gyer, ovezet, ujar);
            }
            else if (tipus == "trolibusz")
            {
                return new Trolibusz(azo, gyer, ovezet, ujar);
            }
            else
            {
                throw new ArgumentException("Ismeretlen Jármű típus");
            }
        }
        public static Hasznalati_ovezet CreateOvezet(string ovezet_tipus)
        {
            if (string.IsNullOrWhiteSpace(ovezet_tipus))
            {
                throw new ArgumentException("A használati övezet nem lehet üres.");
            }
            if (ovezet_tipus == "belvaros")
            {
                return Belvaros.Instance;
            }
            else if (ovezet_tipus == "kulvaros")
            {
                return Kulvaros.Instance;
            }
            else if (ovezet_tipus == "vegyes")
            {
                return Vegyes.Instance;
            }
            else
            {
                throw new ArgumentException("Ismeretlen használati övezet");
            }
        }
    }
}
