package parking;

import vehicle.Car;
import vehicle.Size;
import parking.facility.Space;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.condition.DisabledIf;


public class ParkingLotTest {
    @Test
    public void testConstructorWithInvalidValues() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new ParkingLot(-1, 5);
        }, "Expected IllegalArgumentException for negative rows.");

        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new ParkingLot(5, -1);
        }, "Expected IllegalArgumentException for negative columns.");

        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new ParkingLot(0, 5);
        }, "Expected IllegalArgumentException for zero rows.");

        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new ParkingLot(5, 0);
        }, "Expected IllegalArgumentException for zero columns.");
    }
    @Test
    public void testTextualRepresentation() {
        ParkingLot parkingLot = new ParkingLot(5, 5);
    StringBuilder sb = new StringBuilder();
    for (int i = 0; i < 5; i++) {
        sb.append("X X X X X \n");
    }
    String expected = sb.toString();
    Assertions.assertEquals(expected, parkingLot.toString(), "Expected textual representation to match.");
    }
}
