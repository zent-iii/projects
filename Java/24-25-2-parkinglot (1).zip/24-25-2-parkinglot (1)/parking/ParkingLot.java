package parking;
import parking.facility.Space;
import vehicle.Car;
import vehicle.Size;

public class ParkingLot {
    private final Space[][] floorPlan;
    public ParkingLot(int floorNumber, int spaceNumber) {
        if (floorNumber <= 0 || spaceNumber <= 0) {
            throw new IllegalArgumentException("Floor number and space number must be positive.");
        }
        this.floorPlan = new Space[floorNumber][spaceNumber];
        for (int i = 0; i < floorNumber; i++) {
            for (int j = 0; j < spaceNumber; j++) {
                floorPlan[i][j] = new Space(i, j);
            }
        }
    }
    public Space[][] getFloorPlan() {
        return floorPlan;
    }
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (int i = floorPlan.length - 1; i >= 0; i--) {
            for (int j = 0; j < floorPlan[i].length; j++){
                Space space = floorPlan[i][j];
                if (!space.isTaken()) {
                    sb.append("X");
                }
                else {
                    sb.append(space.getOccupyingCarSize() == Size.SMALL ? "S" : "L");
                }
                sb.append(" ");
            }
            sb.append("\n");
        }
        return sb.toString();
    }
}
