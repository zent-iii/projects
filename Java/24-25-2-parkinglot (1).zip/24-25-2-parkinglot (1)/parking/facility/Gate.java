package parking.facility;

import java.util.ArrayList;
import java.util.Iterator;
import vehicle.Car;
import vehicle.Size;
import parking.ParkingLot;

public class Gate {
    private final ArrayList<Car> cars;
    private final ParkingLot parkingLot;
    public Gate(ParkingLot parkingLot) {
        this.parkingLot = parkingLot;
        this.cars = new ArrayList<>();
    }
    private Space findTakenSpaceByCar(Car c) {
        for (Space[] space : parkingLot.getFloorPlan()) {
            for (Space s : space) {
                if (s.isTaken() && s.getCarLicensePlate().equals(c.getLicensePlate())) {
                    return s;
                }
            }
        }
        return null;
    }
    private Space findAvailableSpaceOnFloor(int floor, Car c) {
        Space[] floorSpace = parkingLot.getFloorPlan()[floor];

    if (c.getSpotOccupation() == Size.SMALL) {
        for (Space s : floorSpace) {
            if (!s.isTaken()) {
                return s;
            }
        }
    } else {
        for (int j = 0; j < floorSpace.length - 1; j++) {
            if (!floorSpace[j].isTaken() && !floorSpace[j + 1].isTaken()) {
                return floorSpace[j];
            }
        }
    }

    return null;
    }
    public Space findAnyAvailableSpaceForCar(Car c) {
        for (int i = parkingLot.getFloorPlan().length - 1; i >= 0; i--) {
            return findAvailableSpaceOnFloor(i, c);
        }
        return null;
    }
    public Space findPreferredAvailableSpaceForCar(Car c) {
        int preferredFloor = c.getPreferredFloor();
        Space space = findAvailableSpaceOnFloor(preferredFloor, c);
        if (space != null) {
            return space;
        }
        for (int i = 0; i < parkingLot.getFloorPlan().length; i++) {
            if (i != preferredFloor) {
                space = findAvailableSpaceOnFloor(i, c);
                if (space != null) {
                    return space;
                }
            }
        }
        return null;
    }
    public boolean registerCar(Car c) {
        Space space = findPreferredAvailableSpaceForCar(c);
    if (space != null) {
        space.addOccupyingCar(c);
        if (c.getSpotOccupation() == Size.LARGE) {
            int floor = space.getFloorNumber();
            int spaceNum = space.getSpaceNumber();
            Space[][] plan = parkingLot.getFloorPlan();
            if (spaceNum + 1 < plan[floor].length) {
                Space right = plan[floor][spaceNum + 1];
                if (!right.isTaken()) {
                    right.addOccupyingCar(c);
                } else {
                    space.removeOccupyingCar();
                    return false;
                }
            } else {
                space.removeOccupyingCar();
                return false;
            }
        }
        cars.add(c);
        return true;
    }
    return false;
    }
    public void registerCars(Car... cars) {
        for (Car c : cars) {
            if (!registerCar(c)) {
                System.out.println("Car " + c.getLicensePlate() + " could not be registered.");
            } else {
                System.out.println("Car " + c.getLicensePlate() + " registered successfully.");
            }
        }
    }
    public void deRegisterCar(String ticketId) {
        Iterator<Car> iterator = cars.iterator();
        while (iterator.hasNext()) {
            Car c = iterator.next();
            if (c.getTicketId().equals(ticketId)) {
                Space space = findTakenSpaceByCar(c);
                if (space != null) {
                    space.removeOccupyingCar();
                    iterator.remove();
                }
            }
        }
    }
}

