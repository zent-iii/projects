package parking.facility;
import vehicle.Car;
import vehicle.Size;
import parking.ParkingLot;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.DisabledIf;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import static org.junit.jupiter.api.Assertions.*;

public class GateTest {
    @Test
    public void testFindAnyAvailableSpaceForCar() {
        ParkingLot parkingLot = new ParkingLot (5, 5);
        Gate gate = new Gate(parkingLot);
        Size size = Size.SMALL;
        Car car = new Car ("ABC123", size, 1);
        Space space = gate.findAnyAvailableSpaceForCar(car);
        Assertions.assertNotNull(space, "Expected to find an available space for the car.");
    }

    @ParameterizedTest
    @CsvSource({
        "ABC123, SMALL, 2",
        "ABC124, LARGE, 3",
    })
    public void testFindPreferredAvailableSpaceForCar(String plate, vehicle.Size size, int preferredFloor) {
        ParkingLot parkingLot = new ParkingLot (5, 5);
        Gate gate = new Gate(parkingLot);
        Car car = new Car (plate, size, preferredFloor);
        Space space = gate.findAnyAvailableSpaceForCar(car);
        Assertions.assertNotNull(space, "Expected to find a preferred available space for the car.");
    }

    @ParameterizedTest
    @CsvSource({
        "ABC123, SMALL, 2",
        "ABC124, LARGE, 3",
    })
    public void testRegisterCar(String plate, vehicle.Size size, int preferredFloor) {
        ParkingLot parkingLot = new ParkingLot (5, 5);
        Gate gate = new Gate(parkingLot);
        Car car = new Car (plate, size, preferredFloor);
        Assertions.assertEquals(true, gate.registerCar(car));
    }

    @ParameterizedTest
    @CsvSource({
        "ABC123, SMALL, 2",
        "ABC124, LARGE, 3",
    })
    public void testDeRegisterCar(String plate, vehicle.Size size, int preferredFloor) {
    ParkingLot parkingLot = new ParkingLot(5, 5);
    Gate gate = new Gate(parkingLot);
    Car car = new Car (plate, size, preferredFloor);
    gate.registerCar(car);
    car.setTicketId("12345");
    Space occupiedSpace = null;
    for (Space[] floor : parkingLot.getFloorPlan()) {
        for (Space s : floor) {
            if (s.isTaken() && s.getCarLicensePlate().equals(car.getLicensePlate())) {
                occupiedSpace = s;
                break;
            }
        }
    }
    Assertions.assertNotNull(occupiedSpace, "A kocsinak regisztrálva kell lennie egy parkolóhelyen.");
    gate.deRegisterCar("12345");
    Assertions.assertFalse(occupiedSpace.isTaken(), "A parkolóhelynek felszabadultnak kell lennie.");
    }
}
